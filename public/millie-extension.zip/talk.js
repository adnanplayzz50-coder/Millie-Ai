const preview = document.getElementById("preview");
const hint = document.getElementById("hint");
const statusEl = document.getElementById("status");
const shareBtn = document.getElementById("share");
const main = document.getElementById("main");
const form = document.getElementById("chatForm");
const input = document.getElementById("input");
const sendBtn = document.getElementById("send");

let stream = null;
let history = [];
let session = null;

const CALL_HINT =
  "(Context: the user is sharing their screen live. The attached image is what their screen shows right now. Answer based on what you can see in it.)";

function addMsg(role, text) {
  const el = document.createElement("div");
  el.className = `msg ${role}`;
  el.textContent = text;
  main.appendChild(el);
  main.scrollTop = main.scrollHeight;
  return el;
}

/** One still frame of the shared screen as a JPEG data URL. Null when not sharing. */
function grabFrame() {
  if (!stream || !preview.videoWidth) return null;
  const c = document.createElement("canvas");
  const scale = Math.min(1, 1600 / preview.videoWidth);
  c.width = Math.round(preview.videoWidth * scale);
  c.height = Math.round(preview.videoHeight * scale);
  c.getContext("2d").drawImage(preview, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.85);
}

function stopSharing() {
  stream?.getTracks().forEach((t) => t.stop());
  stream = null;
  preview.srcObject = null;
  preview.style.display = "none";
  hint.style.display = "block";
  shareBtn.textContent = "Share my screen";
  shareBtn.classList.remove("stop");
  statusEl.textContent = "";
}

shareBtn.onclick = async () => {
  if (stream) return stopSharing();
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
    stream.getVideoTracks()[0].addEventListener("ended", stopSharing);
    preview.srcObject = stream;
    await preview.play();
    preview.style.display = "block";
    hint.style.display = "none";
    shareBtn.textContent = "Stop sharing";
    shareBtn.classList.add("stop");
    statusEl.textContent = "Sharing is on";
  } catch {
    statusEl.textContent = "Screen sharing was cancelled.";
  }
};

async function send(text) {
  if (!session) {
    statusEl.textContent = "Sign in from the Millie popup first.";
    return;
  }
  history.push({ role: "user", content: text });
  const frame = grabFrame();
  const messages = history.map((m, i) => {
    const last = i === history.length - 1;
    if (!last || !frame) return { role: m.role, content: m.content };
    return { role: m.role, content: `${m.content}\n\n${CALL_HINT}`, images: [frame] };
  });
  addMsg("user", text);
  const bot = addMsg("bot", "…");
  const writer = smoothWriter(bot, main);
  sendBtn.disabled = true;
  try {
    const reply = await streamChat(session, messages, { onText: (t) => writer.set(t) });
    writer.flush();
    history.push({ role: "assistant", content: reply });
  } catch (e) {
    writer.flush();
    bot.className = "msg err";
    bot.textContent = e.message || "Something went wrong.";
    history.pop();
  } finally {
    sendBtn.disabled = false;
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text || sendBtn.disabled) return;
  input.value = "";
  send(text);
});

(async function init() {
  session = await validSession();
  applyPrefs(await loadPrefs(session));
  if (!session) statusEl.textContent = "Not signed in. Open the Millie popup first.";
})();
