// Shared by the popup and the talk window: session, personalization, chat API and smooth text.
const SITE = "https://millieai.lovable.app";
const SUPABASE_URL = "https://mhhjezwyhmrzfyyasiqw.supabase.co";
const SUPABASE_KEY = "sb_publishable_3rr1bapPZOkd-mC7HPHIIg_B8G9dF3a";

// The extension always uses the normal system font. The website's font choice is not applied here.
const DEFAULT_FONT = "system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";
document.documentElement.style.setProperty("--font", DEFAULT_FONT);

const Store = {
  get: () => chrome.storage.local.get("session").then((r) => r.session ?? null),
  set: (session) => chrome.storage.local.set({ session }),
  clear: () => chrome.storage.local.remove("session"),
};

/** Returns a valid session, refreshing the token if it has expired. Null means signed out. */
async function validSession() {
  const session = await Store.get();
  if (!session) return null;
  const now = Math.floor(Date.now() / 1000);
  if (session.expires_at && session.expires_at - 60 > now) return session;

  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: { apikey: SUPABASE_KEY, "content-type": "application/json" },
    body: JSON.stringify({ refresh_token: session.refresh_token }),
  });
  if (!res.ok) {
    await Store.clear();
    return null;
  }
  const data = await res.json();
  const fresh = {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: data.expires_at,
    user_id: session.user_id,
    email: session.email,
  };
  await Store.set(fresh);
  return fresh;
}

/** Signs in with email and password. Returns the session or throws. */
async function passwordLogin(email, password) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: { apikey: SUPABASE_KEY, "content-type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  if (!res.ok || !data.access_token) throw new Error(data.error_description || data.msg || "Sign-in failed.");
  const session = {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: data.expires_at ?? Math.floor(Date.now() / 1000) + data.expires_in,
    user_id: data.user?.id ?? "",
    email: data.user?.email ?? email,
  };
  await Store.set(session);
  return session;
}

/** Reads the user's Customize choices from the website (palette, theme, custom color). */
async function loadPrefs(session) {
  const defaults = { palette: "violet", custom_color: null, theme: "dark" };
  if (!session?.user_id) return defaults;
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/user_settings?user_id=eq.${session.user_id}&select=*`, {
      headers: { apikey: SUPABASE_KEY, authorization: `Bearer ${session.access_token}` },
    });
    const rows = await res.json();
    return rows[0] ? { ...defaults, ...rows[0] } : defaults;
  } catch {
    return defaults;
  }
}

const PALETTE_ACCENT = {
  violet: "#7c3aed",
  lavender: "#a78bfa",
  electric: "#c026d3",
};

/** Applies the website's color and theme choices. The font is always the normal system font. */
function applyPrefs(prefs) {
  const root = document.documentElement;
  const dark = prefs.theme === "dark" || (prefs.theme === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
  const accent = prefs.custom_color || PALETTE_ACCENT[prefs.palette] || PALETTE_ACCENT.violet;
  root.style.setProperty("--accent", accent);
  root.style.setProperty("--bg", dark ? "#151515" : "#fafafa");
  root.style.setProperty("--fg", dark ? "#eeeeee" : "#1a1a1a");
  root.style.setProperty("--panel", dark ? "#1e1e1e" : "#ffffff");
  root.style.setProperty("--line", dark ? "#2a2a2a" : "#e5e5e5");
  root.style.setProperty("--muted", dark ? "#999999" : "#666666");
  root.style.setProperty("--font", DEFAULT_FONT);
  root.style.colorScheme = dark ? "dark" : "light";
}

/**
 * Smooth text for streaming replies: updates are batched to one redraw per frame,
 * so text grows evenly instead of jumping in pieces.
 */
function smoothWriter(el, scroller) {
  let latest = "";
  let frame = null;
  return {
    set(text) {
      latest = text;
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = null;
        el.textContent = latest;
        if (scroller) scroller.scrollTop = scroller.scrollHeight;
      });
    },
    flush() {
      if (frame) cancelAnimationFrame(frame);
      frame = null;
      el.textContent = latest;
      if (scroller) scroller.scrollTop = scroller.scrollHeight;
    },
  };
}

/** Sends a chat turn and streams the reply. onText receives the reply so far. */
async function streamChat(session, messages, { mode = "chat", onText } = {}) {
  const res = await fetch(`${SITE}/api/chat`, {
    method: "POST",
    headers: { authorization: `Bearer ${session.access_token}`, "content-type": "application/json" },
    body: JSON.stringify({ messages, mode, webSearch: false, projectId: null }),
  });
  if (!res.ok || !res.body) throw new Error(`Millie couldn't answer (${res.status}).`);

  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  let reply = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      const ev = JSON.parse(line);
      if (ev.type === "text") {
        reply += ev.value;
        onText?.(reply);
      } else if (ev.type === "error") {
        throw new Error(ev.value);
      }
    }
  }
  return reply;
}