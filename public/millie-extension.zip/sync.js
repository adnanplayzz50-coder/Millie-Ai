// Runs on the Millie website. Copies the signed-in session into the extension, so the popup
// and talk window can log in automatically. Also tells the website the extension is installed
// and signed in, so the website can turn on "Hide Ex-Chats". Only runs on millieai.lovable.app.
(function () {
  function findSession() {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !/^sb-.*-auth-token$/.test(key)) continue;
      try {
        const raw = JSON.parse(localStorage.getItem(key));
        const s = raw?.currentSession ?? raw;
        if (s?.access_token && s?.refresh_token) {
          return {
            access_token: s.access_token,
            refresh_token: s.refresh_token,
            expires_at: s.expires_at,
            user_id: s.user?.id ?? "",
            email: s.user?.email ?? "",
          };
        }
      } catch {
        // Not a session entry; keep looking.
      }
    }
    return null;
  }

  function sync() {
    const session = findSession();
    if (!session) return;
    chrome.storage.local.set({ session });
    window.postMessage(
      { source: "millie-extension", type: "ready", version: chrome.runtime.getManifest().version },
      window.location.origin,
    );
  }

  sync();
  setInterval(sync, 30000);
  window.addEventListener("storage", sync);
})();
