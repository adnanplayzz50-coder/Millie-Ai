const main = document.getElementById("main");
const form = document.getElementById("chatForm");
const input = document.getElementById("input");
const sendBtn = document.getElementById("send");
const who = document.getElementById("who");
const signoutBtn = document.getElementById("signout");
const tools = document.getElementById("tools");

let history = [];

function addMsg(role, text) {
  const el = document.createElement("div");
  el.className = `msg ${role}`;
  el.textContent = text;
  main.appendChild(el);
  main.scrollTop = main.scrollHeight;
  return el;
}

function showLogin(note) {
  form.hidden = true;
  tools.hidden = true;
  signoutBtn.hidden = true;
  who.textContent = "";
  main.innerHTML = "";
  const box = document.createElement("div");
  box.className = "login";
  box.innerHTML = `
    <div class="muted">${note}</div>
    <input id="em" type="email" placeholder="Email" />
    <input id="pw" type="password" placeholder="Password" />
    <button class="primary" id="login" style="width:100%;height:36px">Sign in</button>
    <p class="muted"><a id="open">Open Millie</a> while signed in, and this signs you in automatically.</p>
    <div id="loginErr" class="err"></div>`;
  main.appendChild(box);
  document.getElementById("open").onclick = () => chrome.tabs.create({ url: SITE });
  document.getElementById("login").onclick = async () => {
    const err = document.getElementById("loginErr");
    err.textContent = "";
    try {
      const session = await passwordLogin(document.getElementById("em").value.trim(), document.getElementById("pw").value);
      await startSignedIn(session);
    } catch (e) {
      err.textContent = e.message;
    }
  };
}

async function startSignedIn(session) {
  applyPrefs(await loadPrefs(session));
  main.innerHTML = "";
  form.hidden = false;
  tools.hidden = false;
  signoutBtn.hidden = false;
  who.textContent = session.email || "";
  if (!history.length) addMsg("bot", "Hi, how may I help?");
}

async function send(text) {
  const session = await validSession();
  if (!session) return showLogin("Your session expired. Sign in again.");

  history.push({ role: "user", content: text });
  addMsg("user", text);
  const bot = addMsg("bot", "…");
  const writer = smoothWriter(bot, main);
  sendBtn.disabled = true;
  try {
    const reply = await streamChat(session, history, { onText: (t) => writer.set(t) });
    writer.flush();
    history.push({ role: "assistant", content: reply });
  } catch (e) {
    writer.flush();
    bot.className = "msg err";
    bot.textContent = e.message || "Something went wrong.";
    history.pop();
  } finally {
    sendBtn.disabled = false;
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text || sendBtn.disabled) return;
  input.value = "";
  send(text);
});

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});

/**
 * "Talk about my screen": opens Millie in Chrome's own side panel, on the right of the
 * page you're looking at. Both stay inside the same Chrome window.
 */
document.getElementById("talk").onclick = async () => {
  try {
    const win = await chrome.windows.getCurrent();
    await chrome.sidePanel.open({ windowId: win.id });
    window.close();
  } catch (e) {
    addMsg("bot", "Couldn't open the side panel. Click the Millie icon again and try once more.");
  }
};

signoutBtn.addEventListener("click", async () => {
  await Store.clear();
  history = [];
  showLogin("Signed out.");
});

(async function init() {
  const session = await validSession();
  if (session) await startSignedIn(session);
  else showLogin("Open Millie in a tab while signed in, and this signs you in automatically. Or sign in below.");
})();
